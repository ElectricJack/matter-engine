| per-frame mean / p95 | pom_off |
|---|---|
| frames (sampling window) | 170 |
| frame wall ms | 117.85 / 162.03 |
| resolve.sector_lod ms | 0.139 / 0.247 |
| resolve.emit ms | 0.117 / 0.241 |
| instance_cache.match ms | 0.019 / 0.038 |
| cull.vt_demand ms | 0.017 / 0.099 |
| rt.rung_select ms | 0.214 / 0.410 |
| rt.tlas_hash ms | 0.014 / 0.022 |
| geometry.update ms | absent |
| geometry.scene_completion ms | absent |
| geometry.scene_assembly ms | absent |
| instances.sector_lod_scanned | 121 / 131 |
| instances.rt_scanned | 174 / 218 |
| instances.vt_scanned | 16 / 180 |

Top render-lane zones in pom_off (nested zones overlap; do not sum):

| zone | mean ms | p95 ms |
|---|---|---|
| draw | 4.416 | 7.619 |
| draw.cull_render | 3.680 | 7.327 |
| cull.raster | 2.458 | 5.742 |
| raster.rt | 1.470 | 4.286 |
| build | 1.130 | 1.866 |
| raster.gbuffer | 0.802 | 2.497 |
| build.prepare_frame | 0.743 | 0.750 |
| publish | 0.705 | 0.512 |
| draw.vt_requests | 0.686 | 0.308 |
| rt.dispatch | 0.671 | 1.326 |
| publish.vulkan | 0.652 | 0.004 |
| raster.vt_pre | 0.647 | 2.209 |
| cull.vt_begin | 0.636 | 1.175 |
| vt.residency_begin | 0.579 | 1.045 |
| vt.drain_feedback | 0.543 | 0.995 |
