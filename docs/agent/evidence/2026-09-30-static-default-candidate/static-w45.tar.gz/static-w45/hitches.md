| run | frames | GPU total median / p99 / max ms | frame interval median / p99 / max ms | > 100 ms | > 1 s | static uploads in window | peak VRAM MiB |
|---|---|---|---|---|---|---|---|
| pom_off | 170 | 111.11 / 169.55 / 173.20 | 108.87 / 285.11 / 309.79 | 143 | 0 | 5 | 9575 |

| frame interval | pom_off |
|---|---|
| 0–16.7 ms | 0 |
| 16.7–33.3 ms | 0 |
| 33.3–50 ms | 2 |
| 50–100 ms | 25 |
| 100–250 ms | 140 |
| 250–500 ms | 3 |
| 500–1000 ms | 0 |
| 1000–2000 ms | 0 |
| > 2000 ms | 0 |
