| per-frame mean / p95 | pom_off |
|---|---|
| frames (sampling window) | 512 |
| frame wall ms | 37.25 / 34.09 |
| resolve.sector_lod ms | 0.072 / 0.125 |
| resolve.emit ms | 0.058 / 0.111 |
| instance_cache.match ms | 0.008 / 0.019 |
| cull.vt_demand ms | 0.044 / 0.275 |
| rt.rung_select ms | 1.753 / 3.400 |
| rt.tlas_hash ms | 0.079 / 0.115 |
| geometry.update ms | 4.209 / 14.512 |
| geometry.scene_completion ms | 0.211 / 0.467 |
| geometry.scene_assembly ms | 0.932 / 9.566 |
| instances.sector_lod_scanned | 81 / 81 |
| instances.rt_scanned | 1143 / 1279 |
| instances.vt_scanned | 334 / 2130 |

Top render-lane zones in pom_off (nested zones overlap; do not sum):

| zone | mean ms | p95 ms |
|---|---|---|
| draw | 5.642 | 9.472 |
| draw.cull_render | 5.606 | 9.399 |
| cull.raster | 4.900 | 8.461 |
| raster.rt | 4.428 | 7.743 |
| geometry.update | 4.209 | 14.512 |
| build | 3.692 | 12.275 |
| geometry.stream_pages | 2.757 | 5.401 |
| build.prepare_frame | 2.581 | 11.490 |
| rt.geometry | 1.805 | 3.481 |
| rt.rung_select | 1.753 | 3.400 |
| rt.dispatch | 1.345 | 2.496 |
| rt.instances | 1.215 | 2.440 |
| geometry.scene_assembly | 0.932 | 9.566 |
| build.begin_temporal | 0.409 | 0.870 |
| build.update_instances | 0.360 | 1.784 |
