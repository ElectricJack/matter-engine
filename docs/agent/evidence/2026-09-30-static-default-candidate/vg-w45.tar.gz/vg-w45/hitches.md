| run | frames | GPU total median / p99 / max ms | frame interval median / p99 / max ms | > 100 ms | > 1 s | static uploads in window | peak VRAM MiB |
|---|---|---|---|---|---|---|---|
| pom_off | 1412 | 12.05 / 20.39 / 21.98 | 12.02 / 35.17 / 9371.54 | 1 | 1 | 85 | 9497 |

| frame interval | pom_off |
|---|---|
| 0–16.7 ms | 1097 |
| 16.7–33.3 ms | 293 |
| 33.3–50 ms | 17 |
| 50–100 ms | 4 |
| 100–250 ms | 0 |
| 250–500 ms | 0 |
| 500–1000 ms | 0 |
| 1000–2000 ms | 0 |
| > 2000 ms | 1 |
