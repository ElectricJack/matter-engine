| run | frames | GPU total median / p99 / max ms | frame interval median / p99 / max ms | > 100 ms | > 1 s | static uploads in window | peak VRAM MiB |
|---|---|---|---|---|---|---|---|
| pom_off | 147 | 133.73 / 163.90 / 164.59 | 133.48 / 222.15 / 239.76 | 133 | 0 | 63 | 10442 |

| frame interval | pom_off |
|---|---|
| 0–16.7 ms | 0 |
| 16.7–33.3 ms | 0 |
| 33.3–50 ms | 0 |
| 50–100 ms | 14 |
| 100–250 ms | 133 |
| 250–500 ms | 0 |
| 500–1000 ms | 0 |
| 1000–2000 ms | 0 |
| > 2000 ms | 0 |
