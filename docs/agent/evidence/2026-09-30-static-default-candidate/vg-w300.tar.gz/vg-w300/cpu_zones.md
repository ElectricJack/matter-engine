| per-frame mean / p95 | pom_off |
|---|---|
| frames (sampling window) | 147 |
| frame wall ms | 136.65 / 192.62 |
| resolve.sector_lod ms | 0.157 / 0.249 |
| resolve.emit ms | 0.152 / 0.284 |
| instance_cache.match ms | 0.016 / 0.045 |
| cull.vt_demand ms | 1.060 / 3.003 |
| rt.rung_select ms | 11.207 / 15.520 |
| rt.tlas_hash ms | 0.651 / 0.944 |
| geometry.update ms | 21.820 / 54.495 |
| geometry.scene_completion ms | 0.948 / 2.300 |
| geometry.scene_assembly ms | 7.837 / 31.405 |
| instances.sector_lod_scanned | 222 / 223 |
| instances.rt_scanned | 8945 / 9208 |
| instances.vt_scanned | 8544 / 14953 |

Top render-lane zones in pom_off (nested zones overlap; do not sum):

| zone | mean ms | p95 ms |
|---|---|---|
| build | 32.139 | 66.534 |
| draw | 29.557 | 39.897 |
| draw.cull_render | 29.486 | 39.837 |
| cull.raster | 26.816 | 36.594 |
| raster.rt | 25.890 | 35.456 |
| geometry.update | 21.820 | 54.495 |
| build.prepare_frame | 15.246 | 40.416 |
| rt.geometry | 12.029 | 16.722 |
| rt.rung_select | 11.207 | 15.520 |
| build.update_instances | 10.337 | 22.293 |
| geometry.stream_pages | 8.612 | 15.821 |
| rt.instances | 8.336 | 13.068 |
| geometry.scene_assembly | 7.837 | 31.405 |
| rt.dispatch | 5.472 | 7.648 |
| ui.loop | 4.887 | 10.581 |
