| run | frames | GPU total median / p99 / max ms | frame interval median / p99 / max ms | > 100 ms | > 1 s | static uploads in window | peak VRAM MiB |
|---|---|---|---|---|---|---|---|
| pom_off | 258 | 75.91 / 88.44 / 110.85 | 75.55 / 190.00 / 218.47 | 4 | 0 | 5 | 12302 |

| frame interval | pom_off |
|---|---|
| 0–16.7 ms | 0 |
| 16.7–33.3 ms | 1 |
| 33.3–50 ms | 4 |
| 50–100 ms | 249 |
| 100–250 ms | 4 |
| 250–500 ms | 0 |
| 500–1000 ms | 0 |
| 1000–2000 ms | 0 |
| > 2000 ms | 0 |
