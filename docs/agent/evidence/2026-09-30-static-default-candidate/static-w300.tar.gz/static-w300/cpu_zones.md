| per-frame mean / p95 | pom_off |
|---|---|
| frames (sampling window) | 258 |
| frame wall ms | 77.62 / 85.33 |
| resolve.sector_lod ms | 0.300 / 0.599 |
| resolve.emit ms | 0.241 / 0.476 |
| instance_cache.match ms | 0.045 / 0.099 |
| cull.vt_demand ms | 0.020 / 0.033 |
| rt.rung_select ms | 0.619 / 1.193 |
| rt.tlas_hash ms | 0.061 / 0.130 |
| geometry.update ms | absent |
| geometry.scene_completion ms | absent |
| geometry.scene_assembly ms | absent |
| instances.sector_lod_scanned | 265 / 269 |
| instances.rt_scanned | 788 / 834 |
| instances.vt_scanned | 34 / 0 |

Top render-lane zones in pom_off (nested zones overlap; do not sum):

| zone | mean ms | p95 ms |
|---|---|---|
| draw | 4.957 | 9.108 |
| draw.cull_render | 4.492 | 8.828 |
| cull.raster | 3.147 | 6.651 |
| raster.rt | 2.273 | 4.566 |
| build | 1.737 | 2.954 |
| rt.dispatch | 0.915 | 1.795 |
| build.prepare_frame | 0.840 | 0.886 |
| publish | 0.824 | 0.000 |
| publish.vulkan | 0.800 | 0.000 |
| cull.vt_begin | 0.717 | 1.252 |
| rt.geometry | 0.673 | 1.371 |
| vt.residency_begin | 0.655 | 1.164 |
| raster.gbuffer | 0.642 | 1.447 |
| rt.rung_select | 0.619 | 1.193 |
| vt.drain_feedback | 0.604 | 1.058 |
